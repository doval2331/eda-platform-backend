# EDA Platform — Backend (FastAPI)



API REST para análisis exploratorio: dataset IT Ops tabular, reducción (PCA, t-SNE, UMAP) y clustering HDBSCAN.



## Requisitos



- Python 3.11+



## Instalación



```bash

cd eda-platform-backend

python -m venv .venv

.venv\Scripts\activate

pip install -r requirements.txt

copy .env.example .env

```



## 1. Generar dataset sintético IT Ops



```bash

python scripts/generate_it_ops_dataset.py

# → data/it_ops_synthetic_10000.csv



# Opcional: 50k para pruebas de rendimiento

python scripts/generate_it_ops_dataset.py --n 50000 --output data/it_ops_synthetic_50000.csv

```



## 2. Notebook de experimentación (recomendado antes de la API)



```bash

jupyter notebook notebooks/01_it_ops_eda.ipynb

```



El notebook importa los mismos módulos que la API (`app/services/`), de modo que notebook y backend comparten lógica.

### Google Colab

1. Sube el proyecto (ZIP con `app/`, `scripts/`, `notebooks/`) o clona el repo.
2. Abre `notebooks/01_it_ops_eda.ipynb` en Colab.
3. Ejecuta **Setup Colab** → **Seleccionar o subir CSV** (`DATA_MODE = "upload"`) y el resto.
4. Al final, **Exportar artefactos** genera `notebooks/artifacts/`:
   - `pipeline_config.json` — la API lo lee automáticamente
   - `fig_*.png`, `tabla_metricas_reduccion.csv`, `tabla_crosstab_segment_cluster.csv`
5. En Colab se descarga un ZIP; descomprímelo en `notebooks/artifacts/` en tu PC.

## 3. Ejecutar API



```bash

uvicorn app.main:app --reload --port 8000

```



Documentación: http://127.0.0.1:8000/docs



## Endpoints



| Método | Ruta | Descripción |

|--------|------|-------------|

| GET | `/health` | Estado del servicio |

| POST | `/api/runs` | Ejecuta pipeline y persiste resultado |

| GET | `/api/runs` | Lista ejecuciones |

| GET | `/api/runs/{id}` | Detalle |



### Ejemplo IT Ops (principal)



```json

{

  "modality": "it_ops",

  "reduction_method": "UMAP",

  "seed": 42,

  "n_samples": 2000

}

```



Modalidades `texto`, `imagen`, `multimodal`: demo con vectores sintéticos legacy.



## Estructura



```

scripts/generate_it_ops_dataset.py   # Generador CSV

data/it_ops_synthetic_10000.csv      # Dataset (no versionado)

notebooks/01_it_ops_eda.ipynb        # EDA + validación

app/services/it_ops_preprocess.py    # Carga y features

app/services/pipeline_core.py        # Reducción + HDBSCAN

app/services/pipeline.py             # Orquestación por modalidad

app/services/pipeline_config.py      # Lee notebooks/artifacts/pipeline_config.json

notebooks/artifacts/                 # Figuras + JSON exportados desde Colab/Jupyter

```

Tras ejecutar el notebook, copia `pipeline_config.json` a `notebooks/artifacts/`; la API aplicará esos hiperparámetros.

## Frontend



```bash

# Terminal 1

uvicorn app.main:app --reload --port 8000



# Terminal 2

cd eda-platform-frontend

npm run dev

```



## Variables de entorno



| Variable | Default |

|----------|---------|

| `DATABASE_URL` | `sqlite:///./eda_platform.db` |

| `DEFAULT_N_SAMPLES` | `2000` |

| `IT_OPS_DATASET_PATH` | `data/it_ops_synthetic_10000.csv` |



## Base de datos



SQLite por defecto. PostgreSQL: `DATABASE_URL=postgresql+psycopg2://...`


