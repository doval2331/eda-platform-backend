from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import AnalysisRun, get_db, run_to_detail, save_run
from app.schemas import HealthResponse, PipelineMetrics, RunCreateBody, RunDetail, RunSummary
from app.services.pipeline import run_pipeline

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health(db: Annotated[Session, Depends(get_db)]):
    try:
        db.execute(text("SELECT 1"))
        db_status = "ok"
    except Exception:
        db_status = "error"
    return HealthResponse(status="ok", database=db_status)


@router.post("/api/runs", response_model=RunDetail, status_code=201)
def create_run(body: RunCreateBody, db: Annotated[Session, Depends(get_db)]):
    settings = get_settings()
    seed = body.seed if body.seed is not None else settings.default_seed
    n_samples = body.n_samples or settings.default_n_samples

    result = run_pipeline(
        modality=body.modality,
        reduction_method=body.reduction_method,
        seed=seed,
        n_samples=n_samples,
        dataset_path=settings.it_ops_dataset_path,
    )

    payload = {
        "modality": body.modality,
        "reduction_method": body.reduction_method,
        "seed": seed,
        "n_samples": n_samples,
        "result": result.model_dump(),
    }
    row = save_run(db, payload=payload)
    return RunDetail(**run_to_detail(row))


@router.get("/api/runs", response_model=list[RunSummary])
def list_runs(
    db: Annotated[Session, Depends(get_db)],
    limit: int = 20,
):
    limit = min(max(1, limit), 100)
    rows = (
        db.query(AnalysisRun)
        .order_by(AnalysisRun.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        RunSummary(
            id=r.id,
            created_at=r.created_at,
            modality=r.modality,  # type: ignore[arg-type]
            reduction_method=r.reduction_method,  # type: ignore[arg-type]
            seed=r.seed,
            n_samples=r.n_samples,
            outliers_count=r.outliers_count,
            metrics=PipelineMetrics(
                silhouette=float(r.silhouette) if r.silhouette else None,
                davies_bouldin=float(r.davies_bouldin) if r.davies_bouldin else None,
            ),
        )
        for r in rows
    ]


@router.get("/api/runs/{run_id}", response_model=RunDetail)
def get_run(run_id: str, db: Annotated[Session, Depends(get_db)]):
    row = db.get(AnalysisRun, run_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Ejecución no encontrada")
    return RunDetail(**run_to_detail(row))
