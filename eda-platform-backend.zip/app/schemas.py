from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

Modality = Literal["texto", "imagen", "multimodal", "it_ops"]
ReductionMethod = Literal["PCA", "t-SNE", "UMAP"]


class EvidenceMetadata(BaseModel):
    id: str
    preview: str
    source: Modality


class PipelineMetrics(BaseModel):
    silhouette: float | None = None
    davies_bouldin: float | None = None


class PipelineResult(BaseModel):
    X_2d: list[list[float]]
    cluster_labels: list[int]
    outliers_count: int
    metrics: PipelineMetrics
    metadata: list[EvidenceMetadata]


class RunCreateBody(BaseModel):
    """Cuerpo JSON aceptado por el endpoint (snake_case y alias)."""

    modality: Modality = "it_ops"
    reduction_method: ReductionMethod = "UMAP"
    seed: int | None = None
    n_samples: int | None = Field(default=None, ge=30, le=10_000)


class RunSummary(BaseModel):
    id: str
    created_at: datetime
    modality: Modality
    reduction_method: ReductionMethod
    seed: int
    n_samples: int
    outliers_count: int
    metrics: PipelineMetrics


class RunDetail(RunSummary):
    result: PipelineResult


class HealthResponse(BaseModel):
    status: str
    database: str
