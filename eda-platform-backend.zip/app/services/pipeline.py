"""Orquestación del pipeline por modalidad de datos."""

from __future__ import annotations

import random
from pathlib import Path
from typing import Literal

import numpy as np

from app.schemas import EvidenceMetadata, PipelineResult
from app.services.it_ops_preprocess import (
    build_record_preview,
    dataframe_to_features,
    load_it_ops_dataframe,
)
from app.services.pipeline_config import load_pipeline_config
from app.services.pipeline_core import (
    cluster_hdbscan,
    compute_metrics,
    reduce_2d,
    scale_features,
)
from app.services.synthetic_data import (
    _preview,
    generate_high_dim_features,
    seed_for_modality,
)

Modality = Literal["texto", "imagen", "multimodal", "it_ops"]
ReductionMethod = Literal["PCA", "t-SNE", "UMAP"]


def _build_legacy_metadata(
    true_labels: np.ndarray,
    cluster_labels: np.ndarray,
    modality: Literal["texto", "imagen", "multimodal"],
    seed: int,
) -> list[EvidenceMetadata]:
    py_rng = random.Random(seed + 7)
    items: list[EvidenceMetadata] = []
    for i, true_c in enumerate(true_labels):
        preview = _preview(modality, int(true_c), py_rng)
        if cluster_labels[i] == -1:
            preview = (
                "Evidencia atípica (patrón no consistente con los clusters principales)"
            )
        items.append(
            EvidenceMetadata(
                id=f"e{i + 1:03d}",
                preview=preview,
                source=modality,
            )
        )
    return items


def _build_it_ops_metadata(
    df,
    cluster_labels: np.ndarray,
) -> list[EvidenceMetadata]:
    items: list[EvidenceMetadata] = []
    for i in range(len(df)):
        row = df.iloc[i]
        preview = build_record_preview(row)
        if cluster_labels[i] == -1:
            preview = f"[Outlier] {preview}"
        items.append(
            EvidenceMetadata(
                id=str(row.get("client_id", f"C{i + 1:05d}")),
                preview=preview,
                source="it_ops",
            )
        )
    return items


def run_pipeline(
    *,
    modality: Modality = "it_ops",
    reduction_method: ReductionMethod = "UMAP",
    seed: int = 42,
    n_samples: int = 2000,
    n_features: int = 48,
    n_true_clusters: int = 6,
    dataset_path: Path | str | None = None,
) -> PipelineResult:
    effective_seed = seed_for_modality(modality, seed) if modality != "it_ops" else seed

    if modality == "it_ops":
        df = load_it_ops_dataframe(
            dataset_path,
            n_samples=n_samples,
            seed=effective_seed,
        )
        X, _, _meta = dataframe_to_features(df)
        # Features ya escaladas por columna; escalado global adicional opcional
        cfg = load_pipeline_config()
        X_scaled = scale_features(X)
        X_2d = reduce_2d(X_scaled, reduction_method, effective_seed, config=cfg)
        cluster_labels = cluster_hdbscan(X_2d, config=cfg)
        outliers_count = int(np.sum(cluster_labels == -1))
        metrics = compute_metrics(X_2d, cluster_labels)
        metadata = _build_it_ops_metadata(df, cluster_labels)
        return PipelineResult(
            X_2d=X_2d.tolist(),
            cluster_labels=cluster_labels.astype(int).tolist(),
            outliers_count=outliers_count,
            metrics=metrics,
            metadata=metadata,
        )

    effective_seed = seed_for_modality(modality, seed)
    X, true_labels, _ = generate_high_dim_features(
        n_samples=n_samples,
        n_features=n_features,
        n_clusters=n_true_clusters,
        seed=effective_seed,
    )
    cfg = load_pipeline_config()
    X_scaled = scale_features(X)
    X_2d = reduce_2d(X_scaled, reduction_method, effective_seed, config=cfg)
    cluster_labels = cluster_hdbscan(X_2d, config=cfg)
    outliers_count = int(np.sum(cluster_labels == -1))
    metrics = compute_metrics(X_2d, cluster_labels)
    metadata = _build_legacy_metadata(
        true_labels, cluster_labels, modality, effective_seed
    )

    return PipelineResult(
        X_2d=X_2d.tolist(),
        cluster_labels=cluster_labels.astype(int).tolist(),
        outliers_count=outliers_count,
        metrics=metrics,
        metadata=metadata,
    )
